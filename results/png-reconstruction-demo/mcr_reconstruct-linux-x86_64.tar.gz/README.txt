mcr_reconstruct: tested Linux x86-64 ELF, dynamically linked to glibc/libstdc++.
See docs/png-reconstruction-demo.md in dmitrilvovich/Minecraft-Reconstruction.
Usage: ./mcr_reconstruct --image image.png --camera camera.json --output reconstruction.json
This is the PNG application, not the suspended scaling study worker.
Source builds are canonical for other environments. Preserve LICENSES on redistribution.
